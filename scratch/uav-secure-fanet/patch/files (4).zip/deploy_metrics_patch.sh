#!/usr/bin/env bash
# deploy_metrics_patch.sh
# ========================
# Copies the expanded metrics framework into the NS-3 project.
# Run from: ~/ns-allinone-3.43/ns-3.43/scratch/uav-secure-fanet/
#
# USAGE:
#   bash deploy_metrics_patch.sh [PATCH_DIR]
#
# PATCH_DIR defaults to the directory containing this script.

set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
ok()   { echo -e "${GREEN}[OK]${NC}    $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC}  $*"; }
fail() { echo -e "${RED}[FAIL]${NC}  $*"; exit 1; }

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH_DIR="${1:-${SCRIPT_DIR}}"

NS3_ROOT="${NS3_ROOT:-$(cd ../../../.. && pwd)}"
SCRATCH="${NS3_ROOT}/scratch/uav-secure-fanet"

echo "========================================================"
echo "  UAV FANET — Metrics Framework Deployment"
echo "  Patch:   ${PATCH_DIR}"
echo "  Project: ${SCRATCH}"
echo "========================================================"

[[ -d "${SCRATCH}" ]] || fail "Project directory not found: ${SCRATCH}"

# ---------------------------------------------------------------------------
# Deploy metrics/ files
# ---------------------------------------------------------------------------
echo ""
echo "--- Deploying metrics/ ---"
cp "${PATCH_DIR}/metrics/uav-metrics-framework.h"  "${SCRATCH}/metrics/"
ok  "metrics/uav-metrics-framework.h"
cp "${PATCH_DIR}/metrics/uav-metrics-framework.cc" "${SCRATCH}/metrics/"
ok  "metrics/uav-metrics-framework.cc"

# ---------------------------------------------------------------------------
# Deploy graphs/
# ---------------------------------------------------------------------------
echo ""
echo "--- Deploying graphs/ ---"
cp "${PATCH_DIR}/graphs/plot_metrics_full.py" "${SCRATCH}/graphs/"
ok  "graphs/plot_metrics_full.py"

# ---------------------------------------------------------------------------
# Show integration patch
# ---------------------------------------------------------------------------
echo ""
echo "--- Integration notes ---"
echo "  Read: ${PATCH_DIR}/metrics/INTEGRATION_PATCH.cc"
echo "  This file shows EXACTLY what to add to main.cc."
echo ""

# ---------------------------------------------------------------------------
# Add uav-metrics-framework.cc to CMakeLists.txt if not already present
# ---------------------------------------------------------------------------
CMAKE="${SCRATCH}/CMakeLists.txt"
if [[ -f "${CMAKE}" ]]; then
    if grep -q "uav-metrics-framework" "${CMAKE}"; then
        warn "CMakeLists.txt already references uav-metrics-framework"
    else
        # Insert after last existing metrics/*.cc line
        sed -i 's|metrics/uav-pcap-export.cc|metrics/uav-pcap-export.cc\n    metrics/uav-metrics-framework.cc|g' \
            "${CMAKE}" 2>/dev/null \
        || warn "Could not auto-patch CMakeLists.txt — add manually:"
        echo "     metrics/uav-metrics-framework.cc"
        ok  "CMakeLists.txt patched"
    fi
fi

# ---------------------------------------------------------------------------
# Rebuild
# ---------------------------------------------------------------------------
echo ""
echo "--- To rebuild ---"
echo "  cd ${NS3_ROOT}"
echo "  cmake --build cmake-cache/scratch/uav-secure-fanet/ -j\$(nproc)"
echo ""

# ---------------------------------------------------------------------------
# After simulation — generate all graphs
# ---------------------------------------------------------------------------
echo "--- After simulation run ---"
echo "  cd ${SCRATCH}"
echo "  python3 graphs/plot_metrics_full.py"
echo "  # → generates 27+ PNG files in graphs/"
echo ""

echo "========================================================"
echo "  DEPLOYMENT COMPLETE"
echo "========================================================"
